nome = 'Bond, James';

console.log(nome);

var nome;
