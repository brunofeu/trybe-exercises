let idade = 65;

if(idade >= 18 ){
    console.log('Maior  de idade!');
}else{
    console.log('Menor  de idade!');
}

// idade >= 18 ? console.log('Maior  de idade!') : console.log('Menor  de idade!');