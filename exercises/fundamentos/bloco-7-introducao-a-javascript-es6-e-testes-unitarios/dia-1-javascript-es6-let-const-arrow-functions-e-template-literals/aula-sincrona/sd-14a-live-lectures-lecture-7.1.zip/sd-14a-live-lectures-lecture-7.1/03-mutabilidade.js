var nome = 'Alexandre';
console.log('Meu nome é:', nome);

nome = 'Marcia';
console.log('Meu nome é:', nome);

// let nome = 'Alexandre';
// console.log('Meu nome é:', nome);

// nome = 'Marcia';
// console.log('Meu nome é:', nome);

// const nome = 'Alexandre';
// console.log('Meu nome é:', nome);

// nome = 'Marcia';
// console.log('Meu nome é:', nome);