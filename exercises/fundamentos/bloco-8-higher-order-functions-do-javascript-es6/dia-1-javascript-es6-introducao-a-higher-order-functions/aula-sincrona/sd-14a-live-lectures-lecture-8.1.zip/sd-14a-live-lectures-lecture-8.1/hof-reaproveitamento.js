const jogadores = ['Pelé', 'Jairzinho', 'Marta', 'Formiga', 'Hulk', 'Juary', 'Fábio', 'Janderson', 'Sócrates'];




// Filtrar jogadores que o nome não comece pela letra J
// Filtrar jogadores que o nome não comece pela letra F

// Filtrar jogadores que o nome tenha menos que 5 letras
